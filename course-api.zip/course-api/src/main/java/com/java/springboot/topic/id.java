package com.java.springboot.topic;

public @interface id {

}
